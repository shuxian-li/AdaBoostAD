[C_train] = use_ADASYN(C_train);
train_data = cell2mat(C_train'); 