function [gmeans,F1,Auc,Rp,tpr,precision,acc] = f_Gmean(Y,H,Uc)  
numcls = length(Uc);
confMat = confusion( Y,H,Uc );
tpr = diag(confMat)'./sum(confMat,2)';
precision = diag(confMat)'./(sum(confMat,1)+eps); %(sum(confMat,1) - diag(confMat)')./sum(confMat,1);
gmeans = nthroot(prod(tpr),numcls);
fpr = zeros((length(Uc)-1),length(Uc));
for r = 1:length(Uc)
   fpr_tmp = confMat(:,r)./sum(confMat,2);
   fpr_tmp(r) = [];
   fpr(:,r) = fpr_tmp;
end

Auc = mean(mean((1+repmat(tpr,size(fpr,1),1)-fpr)/2)); % (testtpr+testtnr)/2;
F1 = mean((2.*precision.*tpr)./(tpr+precision+eps));
Rp = mean((precision+tpr)/2);
acc = mean(Y==H);

% for i = 1:class_num
%     if sum(N(i,:)) ~= 0
%         recall(i) = N(i,i)/sum(N(i,:));
%     else
%         recall(i) = 0;
%     end
%     if sum(N(:,i)) ~= 0
%         precision(i) = N(i,i)/sum(N(:,i));
%     else
%         precision(i) = 0;
%     end
%     
%     if (recall(i)+precision(i)) ~= 0
%         F_measure_c(i) = 2*(recall(i)*precision(i))/(recall(i)+precision(i));
%     else
%         F_measure_c(i) = 0;
%     end
% end
% Gmean = prod(recall)^(1/class_num);
% F_measure = mean(F_measure_c);
   
end
